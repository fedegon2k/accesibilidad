<!DOCTYPE html>
<html lang="es">

<head>
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-132361279-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
  
    gtag('config', 'UA-132361279-1');
  </script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>APR - Agencia Platense de Recaudación</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Facebook Opengraph integration: https://developers.facebook.com/docs/sharing/opengraph -->
  <meta property="og:title" content="">
  <meta property="og:image" content="">
  <meta property="og:url" content="">
  <meta property="og:site_name" content="">
  <meta property="og:description" content="">

  <!-- Twitter Cards integration: https://dev.twitter.com/cards/  -->
  <meta name="twitter:card" content="summary">
  <meta name="twitter:site" content="">
  <meta name="twitter:title" content="">
  <meta name="twitter:description" content="">
  <meta name="twitter:image" content="">

  <!-- Favicon --> 
  <link href="img/favicon.ico" rel="icon">
  
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/calendar.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css@3.5.2/animate.min.css">

 <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
        async defer>
    </script>
 <script type="text/javascript">
      var onloadCallback = function() {
        grecaptcha.render('html_element', {
          'sitekey' : '6LdYHBwTAAAAANEhfyTD0oSvsv6ry8nPgWRZDRrQ'
        });
      };
    </script>

  <!-- =======================================================
    Theme Name: Bell
    Theme URL: https://bootstrapmade.com/bell-free-bootstrap-4-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
  <script>
jQuery(function($) {
    var path = window.location.href; // because the 'href' property of the DOM element is the absolute path
    $('ul.menu-content a').each(function() {
        if (this.href === path) {
            $(this).addClass('active');
        }
    });
    });
</script>
</head>

<body>
  <!-- Page Content
    ================================================== -->
  <!-- Hero -->

  <!-- /Hero -->


  <!-- Header -->
  <header>
     <div class="container">
      <div class="row margin-top">
        <div class="col-md-3 col-5">
          <a class="hero-brand" href="index.php" title="Home">
            <img src="img/apr.png" alt="" title="" class="img-responsive"/>
        </a>
        </div>
        <div class="col-md-8 col-8">
            <!-- <div id="custom-search-input">
                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="Buscar" />
                    <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button">
                            <i class="fas fa-search"></i>
                        </button>
                    </span>
                </div>
            </div> -->
        </div>
         <div class="col-md-1 col-4 text-right d-none d-md-block">
             <div class="row">
                <div class="col-md-12 col-4 redes">
                    <a href="tel:147"  ><img src="img/147-ico.svg" alt="" title="" class="img-responsive"/></a> 
                    <a href="#" data-api="smartsupp" data-operation="open"  data-toggle="tooltip" data-placement="top" title="Escribinos" 
                        style="position: absolute;
                        font-size: 30px;
                        top: -7px;
                        color: #606060;
                        margin-left: 10px;">
                        <i class="fa fa-comment" ></i>
                        <!--<small style="position: absolute;margin-left: 5px;top: 5px;}">Chat</small>-->
                    </a> 
                </div>      
                <!--<div class="col redes">
                    <a href="#"><img src="img/face-ico.svg" alt="" title="" class="img-responsive"/></a> 
                </div>
                <div class="col redes">
                    <a href="#"><img src="img/instagram-ico.svg" alt="" title="" class="img-responsive"/></a> 
                </div>  
                <div class="col redes">
                    <a href="#"><img src="img/tweeter-ico.svg" alt="" title="" class="img-responsive"/></a> 
                </div>  -->
            </div>      
        </div>
      </div>
    </div>

      <div class="container-fluid" id="header">
            <div class="row">
            <div class="container">
          <nav id="nav-menu-container" class=" col-md-12 col-lg-12">
            <ul class="nav-menu d-flex justify-content-center sf-js-enabled sf-arrows" style="touch-action: pan-y;">
              <li class="li1"><a href="https://autogestion.apronline.gov.ar" target="_blank">AUTOGESTIÓN</a></li> 
              <li class="li2 menu-has-children"><a href="" class="sf-with-ul">NORMATIVA</a>
                    <ul style="display: none;">
                  <li><a href="https://www.laplata.gob.ar/#/transparencia/boletinOficial" target="_blank">Boletín Municipal</a></li>
                  <li><a href="?modulo=ordenanzas">Ordenanzas</a></li>
                  <li><a href="?modulo=resoluciones-generales">Resoluciones Generales</a></li>
                </ul>
                  </li>
               <li class="li3"><a href="?modulo=centros-atencion">CENTROS DE ATENCIÓN</a> </li>

<!--               <li><a href="?modulo=noticias">NOTICIAS</a></li>
 -->              <!-- <li class="menu-has-children"><a href="">Drop Down</a>
               <ul>
                  <li><a href="#">Drop Down 1</a></li>
                  <li class="menu-has-children"><a href="#">Drop Down 2</a>
                    <ul>
                      <li><a href="#">Deep Drop Down 1</a></li>
                      <li><a href="#">Deep Drop Down 2</a></li>
                      <li><a href="#">Deep Drop Down 3</a></li>
                      <li><a href="#">Deep Drop Down 4</a></li>
                      <li><a href="#">Deep Drop Down 5</a></li>
                    </ul>
                  </li>
                  <li><a href="#">CONTACTO</a></li>
                </ul>
              </li> -->
              <li class="li4"><a href="?modulo=linea-municipal">CONTACTO</a></li>
            </ul>
          </nav>
            </div><!-- container -->
            </div>
        <!-- #nav-menu-container -->
     </div>
  </header>
  <!-- #header -->

  
  <!-- About -->
  <section class="about-top" id="about">
    <div class="container text-center">
      <div class="row">
                <div class="stats-col text-center col-md-3 col-6">
            <a href="https://autogestion.apronline.gov.ar/" target="_blank" style="cursor:pointer">
              <div class="circle  bk-celeste" style="border-radius: 20px;">
               <img src=" img/autogestion.svg" alt="" title="" class="img-responsive"/>
              </div>
               <h3>CONSULTÁ Y PAGÁ</h3>
               <p class="text-center">¡Más fácil, rápido y sin regístrarte!</p>
            </a>   
        </div>
               <div class="stats-col text-center col-md-3 col-6">
            <a href="?modulo=habilitaciones" style="cursor:pointer">
              <div class="circle  bk-verde" style="border-radius: 20px;">
               <img src=" img/habilitaciondigi.svg" alt="" title="" class="img-responsive"/>
              </div>
               <h3>HABILITACIONES</h3>
               <p class="text-center">Ahora podés hacer tus trámites ONLINE</p>
            </a>   
        </div>
               <div class="stats-col text-center col-md-3 col-6">
            <a href="?modulo=guia" style="cursor:pointer">
              <div class="circle  bk-magenta" style="border-radius: 20px;">
               <img src=" img/tramites.svg" alt="" title="" class="img-responsive"/>
              </div>
               <h3>GUÍA DE TRÁMITES</h3>
               <p class="text-center">Conocé los requisitos para cada trámite</p>
            </a>   
        </div>
               <div class="stats-col text-center col-md-3 col-6">
            <a href="http://turnos.laplata.gov.ar/misdatos" target="_blank" style="cursor:pointer">
              <div class="circle  bk-violeta" style="border-radius: 20px;">
               <img src=" img/turnos.svg" alt="" title="" class="img-responsive"/>
              </div>
               <h3>TURNOS</h3>
               <p class="text-center">Organizá tu tiempo.</p>
            </a>   
        </div>
             </div>
    </div>
  </section>
  <!-- /About -->
  
   <section class="about" id="about">
    <div class="container">
      <div class="row">







        <div class="col-md-3 col-sm-12">
			<a href="?modulo=monotasa">
				<div class="row accesos-directos">
				  <div class="bk-gris-claro col-md-2 col-2 accesos-directos-claro ">
					<img src="img/monotasa.svg" alt="" title="" class="img-responsive"/>
				  </div>
				  <div class="bk-gris-oscuro col-md-10 col-10 accesos-directos-formularios" style="background: #bc1f79;">
					<p><strong>MONOTASA</strong></p>
				  </div>	
				</div>
			</a>	
        </div>





        <div class="col-md-3 col-sm-12">
			<a href="?modulo=consulta_ex">
				<div class="row accesos-directos">
				  <div class="bk-gris-claro col-md-2 col-2 accesos-directos-claro">
					<img src="img/expedientes.svg" alt="" title="" class="img-responsive"/>
				  </div>
				  <div class="bk-gris-oscuro col-md-10 col-10 accesos-directos-expediente">
					<p><strong>SEGUIMIENTO <br> DE EXPEDIENTES</strong></p>
				  </div>
				</div>
			</a>	
        </div>

       <div class="col-md-3 col-sm-12">
			<a href="http://www.apronline.gov.ar/suav/">
				<div class="row accesos-directos">
				  <div class="bk-gris-claro col-md-2 col-2 accesos-directos-claro">
					<img src="img/suav.svg" alt="" title="" class="img-responsive"/>
				  </div>
				  <div class="bk-gris-oscuro col-md-10 col-10 accesos-directos-suav">
					<p><strong>SUAV</strong><br> SISTEMA ÚNICO<br> DE ATENCIÓN VECINAL</p>
				  </div>
				</div>
			</a>	
        </div>



        <div class="col-md-3 col-sm-12">
			<a href="?modulo=formularios">
				<div class="row accesos-directos">
				  <div class="bk-gris-claro col-md-2 col-2 accesos-directos-claro ">
					<img src="img/formularios.svg" alt="" title="" class="img-responsive"/>
				  </div>
				  <div class="bk-gris-oscuro col-md-10 col-10 accesos-directos-formularios">
					<p><strong>FORMULARIOS</strong></p>
				  </div>	
				</div>
			</a>	
        </div>



		
		</div>
    </div>
  </section>
  <!-- /About -->
  
  
  <!-- vencimientos -->
  

  <section class="containter-fluid vencimientos margin-top text-center">
  <div class="container">
	<div class="row">
		<div class="col-md-4 col-sm-12">
			
		  <h4>VENCIMIENTOS <span>2019</span></h4>
		   <select id="tipoVencimiento" class="form-control form-control-lg border-magenta">
			  <option value="1">TRIBUTO</option>
			  <option value="15">Agentes de Percepción TISH</option>
			  <option value="12">Agentes de Retención (PRESENTACIÓN)</option>
			  <option value="13">Agentes de Retención (PAGO)</option>
			  <option value="10">Automotor</option>
			  <option value="7">Derechos de Espectáculos Públicos</option>
			  <option value="3">Derechos de Publicidad y Propaganda</option>
			  <option value="16">Derechos de Ocupación o Uso de Espacios Públicos - Uso Habitual</option>
			  <option value="8">Derechos de Ocupación o Uso de Espacios Públicos - Uso NO Habitual</option>
			  <option value="6">Coche Escuela - Taxis - Remisses</option>
			  <option value="14">Monotasa</option>
			  <option value="9">Motos</option>
			  <option value="5">Tasa por Habilitación de Emplazamientos de Estructuras Soporte de Antenas</option>
			  <option value="2">Tasas por Inspección de Seguridad e Higiene</option>
 			  <option value="4">Tasa SUM</option>
			  <option value="11">Transporte Escolar</option>
			</select><br/>
			<p><a href="?modulo=vencimientos" class="color-magenta">CALENDARIO ANUAL - AQUÍ</a></p>

<div id="proximo" style="margin-top: 10px"></div>
<br>

		</div>
		<!--CALENDARIO-->
		<div class="col-md-4 col-sm-12 border-right">
				<div id="my-calendar"></div>
		</div>
		<div class="col-lg-4">
		  <h4 class="color-celeste "><strong>LO MÁS BUSCADO ...</strong></h4>

		
			<br>
				<!-- <a href="http://autogestion.apronline.gov.ar"  target="_blank" class="btn-boleta-digital btn-primary d-none d-sm-block">Consultá y pagá</a>
			<br>

			<a  data-toggle="modal" data-target="#digital"  target="_blank" class="btn-boleta-digital btn-primary d-none d-sm-block"style="color:#606060">Adherite a la BOLETA DIGITAL</a>-->




   
  <div class="interes" align="left">
  	           <p><a class="inteers" href="archivos/guia%20rapida%20habilitacion%20online.pdf" target="_blank"><i class="fas fa-square"></i> Habilitación Online – Guía rápida</a></p>
            <p><a class="inteers" href="archivos/guia_autogestion.pdf" target="_blank"><i class="fas fa-square"></i> Portal de Autogestión - Guía rápida</a></p>
            <p><a class="inteers" href="?modulo=noticias&noticia=29" target="_blank"><i class="fas fa-square"></i> MONOTASA - Beneficios</a></p>
            <p><a class="inteers" href="archivos/Publicidadenviapublica.jpg" target="_blank"><i class="fas fa-square"></i> Publicidad permitida y no permitida</a></p>
            <p><a class="inteers" href="archivos/ALTA DE BOLETA DIGITAL_FINAL.pdf" target="_blank"><i class="fas fa-square"></i> Alta Boleta digital</a></p>
      
</div>
<style type="text/css">
.interes i {
	font-size: 11px;
}
.interes a:hover {
text-decoration: none;
color: #C03360 !important;
}
</style>


		





		</div>
      </div>
	  </div>
  </section>
  <!-- /vencimientos -->
  <!-- Features -->
<a href="?modulo=medios-pago">
  <section class="features margin-top" id="medios-pago">
    <div class="container">
      <p class="text-center color-magenta">
         <strong>MEDIOS DE PAGO</strong>
        </p>

      <div class="row">
        <div class="col-lg-6 col-md-6  col-12">
         <img src="img/pagos_01.png" alt="" title="" class="img-responsive"/>
        </div>
		 <div class="col-lg-6 col-md-6 col-12">
         <img src="img/pagos_02.png" alt="" title="" class="img-responsive"/>
        </div>        
    </div>
	</div>
  </section>
</a>
  <!-- /Features -->

  <!-- Team -->

  <section class="team" id="team">
    <div class="container">
     <p class="text-center color-magenta">
     	<a href="?modulo=noticias">

         <strong> NOTICIAS </strong>
     </a>
        </p>
      <div class="row">
    
            
 <div class="col-md-3 col-12">
                <div class="card card-block">
                  <a href="?modulo=noticias&noticia=29">
                <!--   <img alt="" class="dots" src="img/dots.svg">
                  <img alt="" class="team-img" src="assets/plugins/parallax-slider/img/"> -->
                      <div class="card-title-wrap">
                        <span class="card-title">Nuevos beneficios impositi ...</span> 
                        <span class="card-text">La Municipalidad de La Plata, a trav&eacute;s de la Agencia Platense de Recaudaci&oacute;n (APR), ha decidido acompa&ntilde;ar el esfuerzo que hacen l ...</span>
                      </div>
                </a>
              </div>
            </div>



            
 <div class="col-md-3 col-12">
                <div class="card card-block">
                  <a href="?modulo=noticias&noticia=28">
                <!--   <img alt="" class="dots" src="img/dots.svg">
                  <img alt="" class="team-img" src="assets/plugins/parallax-slider/img/"> -->
                      <div class="card-title-wrap">
                        <span class="card-title">Beneficios para productore ...</span> 
                        <span class="card-text">La Municipalidad de La Plata, a trav&eacute;s de la Agencia Platense de Recaudaci&oacute;n (APR), en el marco de las potestades conferidas por el art& ...</span>
                      </div>
                </a>
              </div>
            </div>



            
 <div class="col-md-3 col-12">
                <div class="card card-block">
                  <a href="?modulo=noticias&noticia=27">
                <!--   <img alt="" class="dots" src="img/dots.svg">
                  <img alt="" class="team-img" src="assets/plugins/parallax-slider/img/"> -->
                      <div class="card-title-wrap">
                        <span class="card-title">Importantes beneficios par ...</span> 
                        <span class="card-text">La Agencia Platense de Recaudaci&oacute;n (APR) impuls&oacute;, a partir de este a&ntilde;o, nuevas medidas que favorecen principalmente a los comerci ...</span>
                      </div>
                </a>
              </div>
            </div>



            
 <div class="col-md-3 col-12">
                <div class="card card-block">
                  <a href="?modulo=noticias&noticia=26">
                <!--   <img alt="" class="dots" src="img/dots.svg">
                  <img alt="" class="team-img" src="assets/plugins/parallax-slider/img/"> -->
                      <div class="card-title-wrap">
                        <span class="card-title">Continúa el operativo "AP ...</span> 
                        <span class="card-text">La Agencia Platense de Recaudaci&oacute;n (APR) contin&uacute;a con el operativo &ldquo;APR en la calle&rdquo;, el cual tiene por objetivo la realizac ...</span>
                      </div>
                </a>
              </div>
            </div>



            





<!-- Noticias -->
	</div>



  </section>
  <!-- /Team -->


</div>










<div class="modal fade" id="ultima_boleta" tabindex="-100" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Descargar Boleta</h4>
            </div>
            <div class="modal-body">
            <form  id="imprime">
                    <div class="row-fluid">
                        <div class="span6">
                            <input type="hidden" name="generar_comprobante" id="generar_comprobante">
                            <label for="tipo">Tipo de Imponible </label>
                            <select name="imponible" id="imponible" class="form-control">
                                <option value="I">Inmueble</option>
                                <option value="R">Rodado</option>
                                <option value="C">Comercio</option>
                                <option value="N">Contribuyente</option>
                            </select>
                        </div>
                        <br>    
                        <div class="span6">
                            <div id="inmueble">
                                <label for="partida">Partida:</label>
                                <input name="partida" class="form-control" id="partida" size="6" maxlength="6" type="text">
                                <label for="prepartida">Prepartida:</label>
                                <input name="prepartida" class="form-control" id="prepartida" size="4" value="0000" maxlength="4" type="text">
                            </div>
                            <div id="rodado">
                                <label for="rodado">Dominio del Rodado:</label>
                                <input class="form-control" name="rodado" id="rodadotxt" size="6" maxlength="6" type="text">
                            </div>
                            <div id="comercio">
                                <label for="cuit">CUIT de Comercio:</label>
                                <input class="form-control" name="cuit" id="cuit2" size="13" maxlength="13" type="text">
                            </div>
                            <div id="contribuyente">
                                <label for="cuim">CUIT/CUIL:</label>
                                <input class="form-control" name="cuim" id="cuimtxt" size="13" maxlength="13" type="text">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="padding: 14px 15px 0px !important;">
                    <button type="button" id="imprimir" class="btn-boleta-digital btn-primary "><i class="fa fa-check"></i> Imprimir</button>
                    <button type="button" class="btn-boleta-digital btn-primary " data-dismiss="modal"><i class="fa fa-times"></i> Cancelar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="hide modal fade" id="events-modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body" style="height: 115px"></div>
            <div class="modal-footer" style="padding: 14px 15px 0px !important;">
                <img class="pull-left" src="assets/img/logo1-default.png" width="200px" alt="">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
            </div>
            <img src="assets/img/line.jpg" style=" margin-top: 14px; width:100%; height:4px; " alt="">
        </div>
    </div>
</div>

<div class="modal fade" id="digital" tabindex="-100" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="display: inline;">
                <h4 class="modal-title" id="myModalLabel" align="center">ALTA DE BOLETA DIGITAL</h4>
            </div>
            <div class="modal-body" style="text-align: center;">
            	<p  style="text-align: center;">Ingresá al <a href="https:/autogestion.apronline.gov.ar" target="_blank">Portal de Autogestión</a>, registrate y adherite para recibir tu boleta por correo electrónico.</p>
            	<small >¡Cuidemos juntos el medio ambiente!</small>
           
                </div>
                <div class="modal-footer" style="padding: 14px 15px 0px !important;">
                </div>
        </div>
    </div>
</div>

<style type="text/css">

	.interes{
		text-align: left;
	}
	.interes a {
		color: #6d7172 !important;
	}
	
	.interes> p {
		margin-bottom: 20px; 
		margin-left: 30px;
	}

</style>  <footer class="site-footer margin-top">
    <div class="bottom">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-xs-12 text-lg-left text-center">
            <p class="">
              <strong>INSTITUCIONAL</strong>
            </p>
      <ul class="list">
       <!--  <li class="list-inline-item">
                <a href="?modulo=quienes-somos">Quiénes somos</a>
              </li>

              <li class="list-item">
                <a href="?modulo=mision-vision-valores">Misión, visión y valores</a>
              </li> -->

              <li class="list-item">
                <a href="?modulo=autoridades">Autoridades</a>
              </li>

       <!--        <li class="list-item">
                <a href="?modulo=responsabilidad-tributaria">Responsabilidad tributaria</a>
              </li> -->

              <li class="list-item">
                <a href="?modulo=aviso-legal">Aviso legal</a>
              </li>

          
 
              <li class="list-item">
                <a href="?modulo=noticias">Noticias</a>
              </li>      

                  <li class="list-item">
                <a href="?modulo=legales">Normativa</a>
              </li>

               <li class="list-item">
                <a href="http://intranet.apronline.gov.ar" target="_blank">Uso interno</a>
              </li>
            </ul>
           
          </div>

          <div class="col-lg-4 col-xs-12 text-lg-left text-center">
            <p class="">
              <strong>INFORMACIÓN ÚTIL</strong>
            </p>
      <ul class="list">

    
 <li class="list-item">
                <a href="?modulo=veredas">Plan "Mi Vereda 2019"</a>
              </li> 

             <!--  <li class="list-item">
                <a href="?modulo=enlaces-externos">Enlaces externos</a>
              </li> -->

              <li class="list-item">
                <a href="?modulo=listado-gestores">Listado de gestores</a>
              </li>

              <li class="list-item">
                <a href="?modulo=listado-inspectores">Listado de inspectores</a>
              </li>

              <li class="list-item">
                <a href="?modulo=medios-pago">Medios de pago</a>
              </li>

              <!--   <li class="list-inline-item">
                <a href="assets/pdf/mapadesitioWEB2019.pdf">Mapa del sitio</a>
              </li> -->

             <li class="list-item">
                <a href="?modulo=consulta_fa">Prefactibilidad constructiva</a>
              </li>
              <li class="list-item">
                <a href="?modulo=constancia_inscripcion">Constancia de Inscripción</a>
              </li>

          
            </ul>
           
          </div>
      <div class="col-lg-4 col-xs-12 text-lg-left text-center">
            <p class="">
              <strong>CONTACTO</strong>
            </p>
      <ul class="list">
        <li class="list-item">
                <a href="?modulo=enlaces-externos">Enlaces externos</a>
              </li>
       <li class="list-item">
                <a href="?modulo=centros-atencion">Centros de atención</a>
              </li>
        
         <li class="list-item">
                <a href="http://turnos.laplata.gov.ar/misdatos" target="_blank">Turnos</a>
              </li>
        
        <li class="list-item">
                <a href="?modulo=linea-municipal">Teléfono 147 / 0800 999 5959</a>
              </li>

    <li class="list-item">
                <a href="#" data-api="smartsupp" data-operation="open">Escribinos</a>
              </li>


      

            <!--   <li class="list-item">
                <a href="#features">Mapa de sitio</a>
              </li>
               -->
            </ul>
           
          </div>

        </div>
      </div>
    </div>
  </footer>

   <div class="container-fluid" style="background-color: #F3F3F5">
    <div class="row">
      <div class="col-md-12 col-xs-12">
        <div class="row">
          <div class="col-md-10 col-xs-6">
          </div>
          <div class="col-md-2 col-xs-6 lab-bottom" style="padding-right: 5%;">



<!-- <svg style=" width: 311px;

position: absolute;

bottom: 0px;

right: 93px;" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
   width="507.4px" height="119.061px" viewBox="0 0 507.4 119.061" enable-background="new 0 0 507.4 119.061" xml:space="preserve">
<g>
  <g>
    <g>
      <g>
        <g>
          <path fill="#5B5B5B" d="M278.646,34.903h4.271v15.334h9.705v3.881H278.84L278.646,34.903L278.646,34.903z"/>
        </g>
        <g>
          <path fill="#5B5B5B" d="M302.13,34.709h3.883l8.348,19.409h-4.465l-1.746-4.271h-8.151l-1.747,4.271h-4.271L302.13,34.709z
             M306.597,45.966l-2.523-6.212l-2.523,6.212H306.597z"/>
        </g>
        <g>
          <path fill="#5B5B5B" d="M317.271,34.903h8.931c2.136,0,3.883,0.582,5.047,1.745c0.776,0.775,1.358,1.94,1.358,3.302l0,0
            c0,2.135-1.164,3.299-2.522,4.074c2.135,0.775,3.494,2.137,3.494,4.659l0,0c0,3.493-2.912,5.239-7.185,5.239h-9.121
            L317.271,34.903L317.271,34.903z M328.335,40.532c0-1.165-0.971-1.941-2.718-1.941h-4.076v4.076h3.883
            C327.17,42.667,328.335,42.085,328.335,40.532L328.335,40.532z M326.394,46.161h-4.853v4.271h5.047
            c1.94,0,3.104-0.775,3.104-2.136l0,0C329.499,46.936,328.528,46.161,326.394,46.161z"/>
        </g>
      </g>
      <g>
        <path fill="#5B5B5B" d="M296.308,64.795h4.465v16.111h-4.465V64.795z"/>
      </g>
      <g>
        <path fill="#5B5B5B" d="M307.954,68.871h-4.658v-3.882h13.977v3.882h-4.854v12.229h-4.464V68.871L307.954,68.871z"/>
      </g>
      <g id="XMLID_15_">
        <g>
          <path fill="#3271B2" d="M361.722,58.971c0,0.193,0,0.193,0,0.39c0,30.861-25.039,55.708-55.709,55.708
            c-0.193,0-0.193,0-0.388,0v-0.775v-5.047c0.192,0,0.192,0,0.388,0c27.758,0,50.079-22.519,50.079-50.08
            c0-0.193,0-0.193,0-0.388h5.048L361.722,58.971L361.722,58.971z"/>
          <path fill="#53B8D5" d="M361.722,58.971h-0.775h-5.047c-0.193-27.563-22.518-49.886-50.08-49.886c-0.192,0-0.192,0-0.389,0
            V3.457c0.194,0,0.194,0,0.389,0C336.683,3.458,361.526,28.303,361.722,58.971z"/>
          <path fill="#6851A4" d="M305.625,114.485v0.776c-30.67-0.194-55.515-25.041-55.515-55.71c0-0.191,0-0.191,0-0.388h5.629
            c0,0.194,0,0.194,0,0.388c0,27.563,22.32,49.886,49.886,50.079V114.485L305.625,114.485z"/>
          <path fill="#44B9D4" d="M305.625,3.458v5.629c-27.563,0.193-49.69,22.517-49.886,49.886h-5.629
            C250.305,28.303,274.955,3.651,305.625,3.458z"/>
        </g>
      </g>
    </g>
    <g id="XMLID_14_">
      <g>
        <path fill="#60BED4" d="M284.274,61.105l5.82,5.824c0.194,0.192,0.194,0.581,0,0.774l-5.629,5.629l-6.404-6.404l5.629-5.631
          C283.69,60.913,284.079,60.913,284.274,61.105z"/>
      </g>
      <g>
        <path fill="#53B8D5" d="M277.867,66.93l6.405,6.404l-6.405,6.406l-5.24-5.242c-0.776-0.774-0.776-1.746,0-2.521L277.867,66.93z"
          />
      </g>
      <g>
        <path fill="#6851A4" d="M284.274,73.335l5.629,5.629c0.191,0.195,0.191,0.584,0,0.777l-5.823,5.821
          c-0.194,0.192-0.583,0.192-0.776,0l-5.629-5.629L284.274,73.335z"/>
      </g>
    </g>
    <g id="XMLID_13_">
      <g>
        <path fill="#60BED4" d="M329.499,61.105l-5.822,5.824c-0.193,0.192-0.193,0.581,0,0.774l5.629,5.629l6.405-6.404l-5.629-5.631
          C330.082,60.913,329.694,60.913,329.499,61.105z"/>
      </g>
      <g>
        <path fill="#53B8D5" d="M335.906,66.93l-6.406,6.404l6.406,6.406l5.239-5.242c0.776-0.774,0.776-1.746,0-2.521L335.906,66.93z"
          />
      </g>
      <g>
        <path fill="#6851A4" d="M329.499,73.335l-5.629,5.629c-0.193,0.195-0.193,0.584,0,0.777l5.822,5.821
          c0.193,0.192,0.584,0.192,0.775,0l5.629-5.629L329.499,73.335z"/>
      </g>
    </g>
  </g>
</g>
<g>
  <path fill="none" d="M429.61,5.885c-18.906,0-35.512,9.812-45.035,24.609h90.069C465.12,15.696,448.517,5.885,429.61,5.885z"/>
  <path fill="none" d="M479.861,40.937v15.018h-102.89V49.72c-0.574,3.146-0.894,6.383-0.894,9.696
    c0,29.564,23.967,53.531,53.529,53.531c29.563,0,53.528-23.967,53.528-53.531C483.139,52.921,481.982,46.696,479.861,40.937z"/>
</g>
<rect x="420.147" y="80.869" fill="#AA6FAC" width="7.131" height="6.964"/>
<rect x="405.884" y="80.869" fill="#AA6FAC" width="7.131" height="6.964"/>
<rect x="438.888" y="73.906" fill="#AA6FAC" width="7.133" height="6.963"/>
<rect x="453.058" y="73.906" fill="#AA6FAC" width="7.132" height="6.963"/>
<rect x="445.927" y="80.785" fill="#AA6FAC" width="7.131" height="6.964"/>
<rect x="405.884" y="66.943" fill="#6B5391" width="7.131" height="6.963"/>
<rect x="398.753" y="73.906" fill="#6B5D7C" width="7.131" height="6.963"/>
<rect x="413.015" y="73.906" fill="#6B5391" width="7.134" height="6.963"/>
<rect x="413.015" y="87.794" fill="#6B5391" width="7.134" height="6.963"/>
<rect x="420.147" y="94.757" fill="#6B5391" width="7.131" height="6.964"/>
<rect x="431.759" y="66.943" fill="#6B5391" width="7.129" height="6.963"/>
<rect x="445.927" y="66.943" fill="#6B5391" width="7.131" height="6.963"/>
<rect x="438.795" y="87.755" fill="#6B5391" width="7.132" height="6.963"/>
<path fill="#6B5391" d="M430.269,3c-31.155,0-56.416,25.259-56.416,56.416s25.261,56.416,56.416,56.416
  c31.154,0,56.415-25.259,56.415-56.416C486.684,28.258,461.423,3,430.269,3z M430.267,112.138
  c-27.188,0-49.238-22.048-49.238-49.238c0-27.193,22.05-49.24,49.238-49.24c27.193,0,49.237,22.047,49.237,49.24
  C479.504,90.091,457.46,112.138,430.267,112.138z"/>
<path fill="#AA6FAC" d="M381.028,62.898c0-27.192,22.049-49.239,49.237-49.239V3c-31.153,0-56.413,25.259-56.413,56.416
  s25.26,56.416,56.413,56.416v-3.692C403.076,112.138,381.028,90.091,381.028,62.898z"/>
<rect x="405.915" y="73.929" fill="#EAEAEA" width="7.131" height="6.963"/>
<rect x="438.92" y="66.964" fill="#EAEAEA" width="7.038" height="6.964"/>
<rect x="420.177" y="87.823" fill="#EAEAEA" width="7.133" height="6.949"/>
<rect x="445.958" y="87.77" fill="#EAEAEA" width="7.133" height="6.97"/>
<g>
  <path fill="#5B5B5B" d="M49.82,28.772h5.844c1.17,0,2.244,0.188,3.222,0.566c0.978,0.378,1.82,0.903,2.526,1.574
    s1.252,1.459,1.638,2.365c0.385,0.907,0.578,1.888,0.578,2.944v0.043c0,1.056-0.192,2.041-0.578,2.953
    c-0.386,0.914-0.932,1.706-1.638,2.377c-0.707,0.671-1.549,1.198-2.526,1.584c-0.978,0.385-2.052,0.577-3.222,0.577H49.82V28.772z
     M55.665,40.783c0.671,0,1.285-0.107,1.841-0.321c0.556-0.214,1.031-0.521,1.424-0.92c0.392-0.398,0.699-0.871,0.92-1.413
    c0.221-0.542,0.332-1.148,0.332-1.819v-0.042c0-0.657-0.11-1.264-0.332-1.82c-0.222-0.557-0.528-1.035-0.92-1.435
    c-0.393-0.399-0.867-0.709-1.424-0.932c-0.557-0.221-1.17-0.332-1.841-0.332h-2.547v9.035L55.665,40.783L55.665,40.783z"/>
  <path fill="#5B5B5B" d="M66.562,28.772h11.282v2.933h-8.028v3.04h7.065v2.934h-7.065v3.146h8.135v2.933H66.562V28.772z"/>
  <path fill="#5B5B5B" d="M86.257,43.972c-1.142,0-2.262-0.196-3.361-0.589s-2.098-0.995-2.997-1.809l1.948-2.333
    c0.685,0.557,1.388,0.999,2.109,1.327c0.72,0.329,1.509,0.493,2.365,0.493c0.685,0,1.217-0.125,1.595-0.375
    s0.567-0.597,0.567-1.038v-0.043c0-0.214-0.04-0.403-0.118-0.567c-0.079-0.164-0.229-0.316-0.451-0.46
    c-0.222-0.143-0.529-0.286-0.923-0.428c-0.394-0.143-0.905-0.292-1.535-0.45c-0.758-0.185-1.445-0.392-2.061-0.621
    c-0.616-0.229-1.138-0.51-1.567-0.846c-0.43-0.335-0.762-0.753-0.998-1.252c-0.236-0.5-0.354-1.12-0.354-1.863v-0.042
    c0-0.685,0.127-1.302,0.383-1.852c0.255-0.55,0.613-1.024,1.074-1.424c0.461-0.398,1.011-0.706,1.651-0.921
    c0.64-0.214,1.345-0.32,2.116-0.32c1.099,0,2.109,0.164,3.029,0.491c0.92,0.329,1.766,0.8,2.537,1.413l-1.712,2.483
    c-0.671-0.457-1.327-0.817-1.97-1.081c-0.642-0.264-1.284-0.396-1.927-0.396c-0.642,0-1.124,0.125-1.445,0.375
    c-0.321,0.25-0.482,0.56-0.482,0.931v0.043c0,0.243,0.047,0.453,0.14,0.631c0.093,0.179,0.261,0.339,0.504,0.482
    c0.243,0.143,0.576,0.277,0.998,0.406c0.422,0.128,0.955,0.278,1.6,0.449c0.758,0.2,1.434,0.425,2.028,0.674
    c0.594,0.25,1.094,0.551,1.502,0.899c0.408,0.35,0.716,0.76,0.923,1.23c0.208,0.472,0.312,1.035,0.312,1.691v0.042
    c0,0.742-0.135,1.402-0.404,1.98c-0.269,0.577-0.645,1.063-1.127,1.456c-0.482,0.393-1.058,0.691-1.726,0.898
    C87.811,43.869,87.07,43.972,86.257,43.972z"/>
  <path fill="#5B5B5B" d="M99.745,28.666h3.04l6.423,15.093h-3.447l-1.37-3.36h-6.337l-1.37,3.36h-3.361L99.745,28.666z
     M103.212,37.486l-1.991-4.86l-1.991,4.86H103.212z"/>
  <path fill="#5B5B5B" d="M111.519,28.772h6.851c1.898,0,3.354,0.507,4.367,1.52c0.856,0.856,1.285,1.999,1.285,3.425v0.043
    c0,1.214-0.296,2.202-0.889,2.966c-0.592,0.764-1.367,1.323-2.323,1.681l3.661,5.352h-3.854l-3.211-4.795h-0.043h-2.547v4.795
    h-3.297V28.772L111.519,28.772z M118.155,36.051c0.813,0,1.438-0.191,1.873-0.577s0.653-0.899,0.653-1.541v-0.043
    c0-0.714-0.229-1.249-0.685-1.605c-0.457-0.357-1.092-0.536-1.905-0.536h-3.275v4.303H118.155z"/>
  <path fill="#5B5B5B" d="M126.997,28.772h6.851c1.898,0,3.354,0.507,4.367,1.52c0.856,0.856,1.285,1.999,1.285,3.425v0.043
    c0,1.214-0.296,2.202-0.889,2.966c-0.592,0.764-1.367,1.323-2.323,1.681l3.661,5.352h-3.854l-3.211-4.795h-0.043h-2.547v4.795
    h-3.297V28.772z M133.633,36.051c0.813,0,1.438-0.191,1.873-0.577s0.653-0.899,0.653-1.541v-0.043c0-0.714-0.229-1.249-0.685-1.605
    c-0.457-0.357-1.092-0.536-1.905-0.536h-3.275v4.303H133.633z"/>
  <path fill="#5B5B5B" d="M149.753,44.015c-1.156,0-2.219-0.203-3.19-0.61s-1.809-0.956-2.516-1.648
    c-0.706-0.691-1.256-1.506-1.648-2.44c-0.393-0.936-0.588-1.938-0.588-3.008v-0.042c0-1.071,0.2-2.073,0.599-3.009
    c0.399-0.935,0.953-1.755,1.659-2.462c0.707-0.706,1.548-1.263,2.526-1.669s2.044-0.609,3.201-0.609
    c1.156,0,2.219,0.203,3.189,0.609c0.971,0.407,1.809,0.956,2.516,1.648c0.707,0.691,1.256,1.506,1.648,2.439
    c0.393,0.936,0.589,1.938,0.589,3.009v0.043c0,1.069-0.2,2.072-0.6,3.008c-0.4,0.935-0.953,1.755-1.659,2.462
    s-1.549,1.263-2.526,1.67C151.976,43.812,150.909,44.015,149.753,44.015z M149.796,40.975c0.656,0,1.263-0.121,1.819-0.364
    c0.556-0.243,1.031-0.578,1.424-1.006c0.393-0.429,0.699-0.924,0.92-1.488c0.221-0.563,0.332-1.167,0.332-1.809v-0.042
    c0-0.644-0.111-1.249-0.332-1.82s-0.535-1.07-0.942-1.499c-0.407-0.429-0.888-0.767-1.445-1.017
    c-0.557-0.25-1.164-0.375-1.82-0.375c-0.671,0-1.281,0.121-1.831,0.363c-0.549,0.243-1.021,0.578-1.413,1.006
    c-0.393,0.429-0.7,0.925-0.921,1.488c-0.221,0.564-0.332,1.167-0.332,1.81v0.043c0,0.642,0.11,1.249,0.332,1.818
    c0.221,0.571,0.535,1.071,0.942,1.499c0.407,0.428,0.885,0.769,1.435,1.018C148.515,40.851,149.125,40.975,149.796,40.975z"/>
  <path fill="#5B5B5B" d="M160.671,28.772h3.297v12.01h7.472v2.976h-10.769V28.772z"/>
  <path fill="#5B5B5B" d="M173.923,28.772h3.297v12.01h7.472v2.976h-10.769V28.772z"/>
  <path fill="#5B5B5B" d="M192.313,28.666h3.04l6.423,15.093h-3.447l-1.37-3.36h-6.337l-1.37,3.36h-3.361L192.313,28.666z
     M195.78,37.486l-1.991-4.86l-1.991,4.86H195.78z"/>
  <path fill="#5B5B5B" d="M204.087,28.772h5.844c1.17,0,2.244,0.188,3.222,0.566s1.82,0.903,2.526,1.574
    c0.706,0.671,1.252,1.459,1.638,2.365c0.385,0.907,0.578,1.888,0.578,2.944v0.043c0,1.056-0.192,2.041-0.578,2.953
    c-0.386,0.914-0.932,1.706-1.638,2.377c-0.707,0.671-1.549,1.198-2.526,1.584c-0.978,0.385-2.052,0.577-3.222,0.577h-5.844V28.772z
     M209.931,40.783c0.671,0,1.285-0.107,1.841-0.321s1.031-0.521,1.424-0.92c0.392-0.398,0.699-0.871,0.92-1.413
    c0.221-0.542,0.332-1.148,0.332-1.819v-0.042c0-0.657-0.11-1.264-0.332-1.82c-0.222-0.557-0.528-1.035-0.92-1.435
    c-0.393-0.399-0.867-0.709-1.424-0.932c-0.557-0.221-1.17-0.332-1.841-0.332h-2.547v9.035L209.931,40.783L209.931,40.783z"/>
  <path fill="#5B5B5B" d="M228.107,44.015c-1.156,0-2.219-0.203-3.19-0.61s-1.809-0.956-2.516-1.648
    c-0.706-0.691-1.256-1.506-1.648-2.44c-0.393-0.936-0.588-1.938-0.588-3.008v-0.042c0-1.071,0.2-2.073,0.599-3.009
    c0.399-0.935,0.953-1.755,1.659-2.462c0.707-0.706,1.548-1.263,2.526-1.669c0.978-0.406,2.044-0.609,3.201-0.609
    c1.156,0,2.219,0.203,3.189,0.609c0.971,0.407,1.809,0.956,2.516,1.648c0.707,0.691,1.256,1.506,1.648,2.439
    c0.393,0.936,0.589,1.938,0.589,3.009v0.043c0,1.069-0.2,2.072-0.6,3.008c-0.4,0.935-0.953,1.755-1.659,2.462
    s-1.549,1.263-2.526,1.67C230.33,43.812,229.263,44.015,228.107,44.015z M228.15,40.975c0.656,0,1.263-0.121,1.819-0.364
    c0.556-0.243,1.031-0.578,1.424-1.006c0.393-0.429,0.699-0.924,0.92-1.488c0.221-0.563,0.332-1.167,0.332-1.809v-0.042
    c0-0.644-0.111-1.249-0.332-1.82s-0.535-1.07-0.942-1.499c-0.407-0.429-0.888-0.767-1.445-1.017
    c-0.557-0.25-1.164-0.375-1.82-0.375c-0.671,0-1.281,0.121-1.831,0.363c-0.549,0.243-1.021,0.578-1.413,1.006
    c-0.393,0.429-0.7,0.925-0.921,1.488c-0.221,0.564-0.332,1.167-0.332,1.81v0.043c0,0.642,0.11,1.249,0.332,1.818
    c0.221,0.571,0.535,1.071,0.942,1.499c0.407,0.428,0.885,0.769,1.435,1.018C226.869,40.851,227.479,40.975,228.15,40.975z"/>
  <path fill="#5B5B5B" d="M5.227,54.462h3.297v14.986H5.227V54.462z"/>
  <path fill="#5B5B5B" d="M12.271,54.462h3.04l7.022,9.228v-9.228h3.254v14.986h-2.805l-7.257-9.527v9.527h-3.254V54.462z"/>
  <path fill="#5B5B5B" d="M32.672,57.502h-4.56v-3.04h12.417v3.04h-4.56v11.946h-3.297V57.502z"/>
  <path fill="#5B5B5B" d="M43.055,54.462h11.282v2.934h-8.028v3.04h7.065v2.933h-7.065v3.147h8.135v2.933H43.055V54.462z"/>
  <path fill="#5B5B5B" d="M64.613,69.705c-1.17,0-2.237-0.191-3.2-0.578c-0.963-0.385-1.792-0.92-2.483-1.604
    c-0.692-0.687-1.231-1.498-1.616-2.44c-0.386-0.941-0.578-1.97-0.578-3.083v-0.043c0-1.07,0.196-2.073,0.588-3.008
    c0.393-0.935,0.938-1.755,1.638-2.462c0.699-0.706,1.527-1.263,2.483-1.669c0.956-0.407,2.005-0.61,3.147-0.61
    c0.67,0,1.281,0.046,1.83,0.14c0.549,0.093,1.06,0.225,1.531,0.396c0.471,0.171,0.913,0.385,1.327,0.642
    c0.414,0.258,0.813,0.551,1.199,0.879l-2.077,2.505c-0.286-0.243-0.571-0.457-0.856-0.644c-0.286-0.185-0.582-0.342-0.889-0.471
    c-0.307-0.128-0.639-0.229-0.995-0.3c-0.357-0.071-0.75-0.107-1.178-0.107c-0.599,0-1.16,0.125-1.68,0.375
    c-0.521,0.25-0.978,0.586-1.37,1.009c-0.393,0.422-0.7,0.916-0.921,1.48c-0.221,0.563-0.332,1.169-0.332,1.813v0.042
    c0,0.688,0.11,1.319,0.332,1.899c0.221,0.579,0.535,1.084,0.942,1.512c0.407,0.431,0.885,0.763,1.435,0.998
    c0.549,0.236,1.159,0.354,1.831,0.354c1.227,0,2.262-0.303,3.104-0.905v-2.156h-3.318V60.82h6.508v6.507
    c-0.771,0.657-1.688,1.218-2.751,1.682C67.2,69.473,65.983,69.705,64.613,69.705z"/>
  <path fill="#5B5B5B" d="M74.183,54.462h6.851c1.898,0,3.354,0.507,4.367,1.521c0.856,0.855,1.285,1.999,1.285,3.425v0.043
    c0,1.213-0.296,2.202-0.889,2.965c-0.593,0.764-1.367,1.324-2.323,1.681l3.661,5.353h-3.854l-3.211-4.796h-0.043H77.48v4.796
    h-3.297V54.462L74.183,54.462z M80.819,61.741c0.813,0,1.438-0.192,1.873-0.578c0.435-0.385,0.653-0.898,0.653-1.541v-0.043
    c0-0.713-0.229-1.249-0.685-1.604c-0.457-0.357-1.092-0.536-1.905-0.536H77.48v4.303H80.819z"/>
  <path fill="#5B5B5B" d="M94.799,54.355h3.04l6.423,15.093h-3.447l-1.37-3.361h-6.337l-1.37,3.361h-3.361L94.799,54.355z
     M98.267,63.176l-1.991-4.859l-1.991,4.859H98.267z"/>
  <path fill="#5B5B5B" d="M106.573,54.462h3.554l3.939,6.337l3.939-6.337h3.554v14.986h-3.254v-9.784l-4.217,6.402h-0.085
    l-4.175-6.337v9.719h-3.254L106.573,54.462L106.573,54.462z"/>
  <path fill="#5B5B5B" d="M125.155,54.462h11.282v2.934h-8.028v3.04h7.065v2.933h-7.065v3.147h8.135v2.933h-11.389V54.462z"/>
  <path fill="#5B5B5B" d="M139.499,54.462h3.04l7.022,9.228v-9.228h3.254v14.986h-2.805l-7.257-9.527v9.527h-3.254V54.462z"/>
  <path fill="#5B5B5B" d="M159.901,57.502h-4.56v-3.04h12.417v3.04h-4.56v11.946h-3.297V57.502z"/>
  <path fill="#5B5B5B" d="M170.284,54.462h11.282v2.934h-8.028v3.04h7.065v2.933h-7.065v3.147h8.135v2.933h-11.389V54.462z"/>
  <path fill="#5B5B5B" d="M191.049,54.462h6.123c0.899,0,1.702,0.125,2.409,0.375s1.306,0.604,1.798,1.061
    c0.492,0.457,0.87,1.002,1.134,1.638c0.264,0.636,0.396,1.338,0.396,2.108v0.043c0,0.871-0.157,1.634-0.471,2.291
    c-0.314,0.656-0.746,1.207-1.295,1.647c-0.549,0.443-1.191,0.774-1.927,0.996c-0.735,0.221-1.523,0.332-2.365,0.332h-2.505v4.495
    h-3.297V54.462z M196.958,62.02c0.828,0,1.47-0.217,1.927-0.652c0.457-0.436,0.685-0.975,0.685-1.617v-0.043
    c0-0.742-0.239-1.306-0.717-1.69c-0.479-0.386-1.131-0.578-1.959-0.578h-2.547v4.582L196.958,62.02L196.958,62.02z"/>
  <path fill="#5B5B5B" d="M212.629,69.705c-1.156,0-2.219-0.203-3.19-0.609s-1.809-0.956-2.516-1.647
    c-0.706-0.693-1.256-1.506-1.648-2.441c-0.393-0.935-0.588-1.938-0.588-3.008v-0.043c0-1.07,0.2-2.073,0.599-3.008
    s0.953-1.755,1.659-2.462c0.707-0.706,1.548-1.263,2.526-1.669c0.978-0.407,2.044-0.61,3.201-0.61c1.156,0,2.219,0.203,3.189,0.61
    c0.971,0.407,1.809,0.956,2.516,1.647c0.707,0.692,1.256,1.507,1.648,2.44c0.393,0.935,0.589,1.938,0.589,3.007v0.043
    c0,1.07-0.2,2.074-0.6,3.008c-0.4,0.937-0.953,1.756-1.659,2.463c-0.707,0.706-1.549,1.264-2.526,1.67
    S213.785,69.705,212.629,69.705z M212.672,66.665c0.656,0,1.263-0.121,1.819-0.364c0.557-0.241,1.031-0.577,1.424-1.006
    c0.393-0.428,0.699-0.924,0.92-1.487s0.332-1.166,0.332-1.81v-0.043c0-0.643-0.111-1.249-0.332-1.818
    c-0.221-0.57-0.535-1.07-0.942-1.499c-0.407-0.43-0.888-0.768-1.445-1.018c-0.557-0.25-1.164-0.375-1.82-0.375
    c-0.671,0-1.281,0.122-1.831,0.364c-0.549,0.243-1.021,0.578-1.413,1.006c-0.393,0.428-0.7,0.924-0.921,1.488
    c-0.221,0.563-0.332,1.167-0.332,1.809v0.043c0,0.644,0.11,1.25,0.332,1.82c0.222,0.57,0.535,1.07,0.942,1.498
    c0.407,0.428,0.885,0.768,1.435,1.018C211.391,66.541,212,66.665,212.672,66.665z"/>
  <path fill="#5B5B5B" d="M223.547,54.462h6.851c1.898,0,3.354,0.507,4.367,1.521c0.856,0.855,1.285,1.999,1.285,3.425v0.043
    c0,1.213-0.296,2.202-0.889,2.965c-0.593,0.764-1.367,1.324-2.323,1.681l3.661,5.353h-3.854l-3.211-4.796h-0.043h-2.547v4.796
    h-3.297V54.462z M230.184,61.741c0.813,0,1.438-0.192,1.873-0.578c0.435-0.385,0.653-0.898,0.653-1.541v-0.043
    c0-0.713-0.229-1.249-0.685-1.604c-0.457-0.357-1.092-0.536-1.905-0.536h-3.275v4.303H230.184z"/>
  <path fill="#5B5B5B" d="M41.407,80.152h3.554l3.939,6.336l3.939-6.336h3.554v14.985h-3.254v-9.783l-4.217,6.399h-0.085
    l-4.175-6.337v9.721h-3.254L41.407,80.152L41.407,80.152z"/>
  <path fill="#5B5B5B" d="M67.268,95.395c-1.156,0-2.219-0.203-3.19-0.61c-0.971-0.406-1.809-0.956-2.516-1.647
    c-0.706-0.691-1.256-1.506-1.648-2.44c-0.393-0.935-0.588-1.938-0.588-3.008v-0.043c0-1.07,0.2-2.072,0.599-3.008
    c0.399-0.936,0.953-1.756,1.659-2.463c0.707-0.706,1.548-1.263,2.526-1.67c0.978-0.405,2.044-0.609,3.201-0.609
    c1.156,0,2.219,0.204,3.189,0.609c0.971,0.407,1.809,0.957,2.516,1.648c0.707,0.692,1.256,1.506,1.648,2.439
    c0.393,0.937,0.589,1.938,0.589,3.009v0.043c0,1.069-0.2,2.072-0.6,3.008c-0.4,0.936-0.953,1.756-1.659,2.462
    c-0.707,0.707-1.549,1.264-2.526,1.67C69.491,95.191,68.424,95.395,67.268,95.395z M67.311,92.354c0.656,0,1.263-0.121,1.819-0.364
    c0.557-0.242,1.031-0.577,1.424-1.006c0.393-0.428,0.699-0.924,0.92-1.487c0.221-0.563,0.332-1.167,0.332-1.81v-0.043
    c0-0.643-0.111-1.248-0.332-1.819c-0.221-0.57-0.535-1.07-0.942-1.499c-0.407-0.428-0.888-0.767-1.445-1.017
    c-0.557-0.249-1.164-0.375-1.82-0.375c-0.671,0-1.281,0.122-1.831,0.363c-0.549,0.243-1.021,0.578-1.413,1.007
    c-0.393,0.429-0.7,0.925-0.921,1.487c-0.221,0.564-0.332,1.167-0.332,1.81v0.043c0,0.643,0.11,1.249,0.332,1.819
    c0.221,0.57,0.535,1.07,0.942,1.498c0.407,0.43,0.885,0.769,1.435,1.018C66.03,92.229,66.64,92.354,67.311,92.354z"/>
  <path fill="#5B5B5B" d="M78.186,80.152h5.844c1.17,0,2.244,0.188,3.222,0.565c0.978,0.38,1.82,0.903,2.526,1.574
    s1.252,1.459,1.638,2.365c0.385,0.906,0.578,1.888,0.578,2.943v0.043c0,1.057-0.192,2.041-0.578,2.955
    c-0.386,0.912-0.932,1.705-1.638,2.376c-0.707,0.671-1.549,1.198-2.526,1.584c-0.978,0.386-2.052,0.577-3.222,0.577h-5.844V80.152z
     M84.03,92.162c0.671,0,1.285-0.106,1.841-0.321c0.556-0.214,1.031-0.521,1.424-0.921c0.392-0.398,0.699-0.87,0.92-1.413
    c0.221-0.542,0.332-1.147,0.332-1.818v-0.043c0-0.656-0.11-1.264-0.332-1.819c-0.222-0.557-0.528-1.035-0.92-1.435
    c-0.393-0.399-0.867-0.71-1.424-0.932s-1.17-0.332-1.841-0.332h-2.547v9.034H84.03z"/>
  <path fill="#5B5B5B" d="M94.927,80.152h11.282v2.933h-8.028v3.04h7.065v2.934h-7.065v3.146h8.135v2.934H94.927V80.152z"/>
  <path fill="#5B5B5B" d="M109.271,80.152h6.851c1.898,0,3.354,0.506,4.367,1.52c0.856,0.856,1.285,1.998,1.285,3.427v0.042
    c0,1.214-0.296,2.201-0.889,2.966c-0.593,0.764-1.367,1.323-2.323,1.68l3.661,5.354h-3.854l-3.211-4.797h-0.043h-2.547v4.797
    h-3.297V80.152z M115.907,87.431c0.813,0,1.438-0.192,1.873-0.578c0.435-0.386,0.653-0.899,0.653-1.541v-0.043
    c0-0.714-0.229-1.249-0.685-1.605c-0.457-0.355-1.092-0.535-1.905-0.535h-3.275v4.304L115.907,87.431L115.907,87.431z"/>
  <path fill="#5B5B5B" d="M124.749,80.152h3.04l7.022,9.227v-9.227h3.254v14.985h-2.805l-7.257-9.526v9.526h-3.254V80.152z"/>
  <path fill="#5B5B5B" d="M141.811,80.152h3.297v14.985h-3.297V80.152z"/>
  <path fill="#5B5B5B" d="M148.404,92.633l8.242-9.591h-7.985v-2.89h12.224v2.504l-8.242,9.592h8.242v2.891h-12.481V92.633z"/>
  <path fill="#5B5B5B" d="M169.149,80.045h3.04l6.423,15.094h-3.447l-1.37-3.361h-6.337l-1.37,3.361h-3.361L169.149,80.045z
     M172.617,88.865l-1.991-4.859l-1.991,4.859H172.617z"/>
  <path fill="#5B5B5B" d="M187.945,95.395c-1.099,0-2.12-0.2-3.062-0.601c-0.942-0.399-1.755-0.944-2.44-1.638
    c-0.685-0.691-1.22-1.509-1.605-2.451c-0.386-0.94-0.578-1.948-0.578-3.019v-0.043c0-1.07,0.192-2.072,0.578-3.009
    c0.385-0.935,0.92-1.755,1.605-2.462c0.685-0.706,1.505-1.263,2.462-1.67c0.956-0.405,2.012-0.609,3.168-0.609
    c0.699,0,1.338,0.058,1.916,0.172c0.578,0.114,1.103,0.271,1.573,0.471c0.471,0.2,0.906,0.442,1.306,0.729
    c0.399,0.285,0.771,0.6,1.113,0.941l-2.098,2.419c-0.585-0.526-1.181-0.94-1.788-1.241c-0.607-0.3-1.288-0.449-2.044-0.449
    c-0.628,0-1.209,0.122-1.745,0.363c-0.535,0.243-0.996,0.578-1.381,1.007c-0.385,0.429-0.685,0.925-0.899,1.487
    c-0.214,0.564-0.321,1.167-0.321,1.81v0.043c0,0.643,0.107,1.249,0.321,1.819c0.214,0.57,0.51,1.07,0.889,1.498
    c0.378,0.43,0.835,0.769,1.37,1.018c0.535,0.25,1.124,0.375,1.766,0.375c0.856,0,1.581-0.157,2.173-0.472
    c0.592-0.313,1.181-0.741,1.766-1.283l2.098,2.118c-0.385,0.414-0.785,0.785-1.199,1.113s-0.867,0.61-1.359,0.847
    c-0.493,0.234-1.031,0.413-1.617,0.534C189.33,95.334,188.673,95.395,187.945,95.395z"/>
  <path fill="#5B5B5B" d="M196.873,80.152h3.297v14.985h-3.297V80.152z"/>
  <path fill="#5B5B5B" d="M211.194,95.395c-1.156,0-2.219-0.203-3.19-0.61c-0.971-0.406-1.809-0.956-2.516-1.647
    c-0.706-0.691-1.256-1.506-1.648-2.44c-0.393-0.935-0.588-1.938-0.588-3.008v-0.043c0-1.07,0.2-2.072,0.599-3.008
    s0.953-1.756,1.659-2.463c0.707-0.706,1.548-1.263,2.526-1.67c0.978-0.405,2.044-0.609,3.201-0.609
    c1.156,0,2.219,0.204,3.189,0.609c0.971,0.407,1.809,0.957,2.516,1.648c0.707,0.692,1.256,1.506,1.648,2.439
    c0.393,0.937,0.589,1.938,0.589,3.009v0.043c0,1.069-0.2,2.072-0.6,3.008s-0.953,1.756-1.659,2.462
    c-0.707,0.707-1.549,1.264-2.526,1.67S212.351,95.395,211.194,95.395z M211.237,92.354c0.656,0,1.263-0.121,1.819-0.364
    c0.557-0.242,1.031-0.577,1.424-1.006c0.393-0.428,0.699-0.924,0.92-1.487c0.221-0.563,0.332-1.167,0.332-1.81v-0.043
    c0-0.643-0.111-1.248-0.332-1.819c-0.221-0.57-0.535-1.07-0.942-1.499c-0.407-0.428-0.888-0.767-1.445-1.017
    c-0.557-0.249-1.164-0.375-1.82-0.375c-0.671,0-1.281,0.122-1.831,0.363c-0.549,0.243-1.021,0.578-1.413,1.007
    c-0.393,0.429-0.7,0.925-0.921,1.487c-0.221,0.564-0.332,1.167-0.332,1.81v0.043c0,0.643,0.11,1.249,0.332,1.819
    c0.221,0.57,0.535,1.07,0.942,1.498c0.407,0.43,0.885,0.769,1.435,1.018C209.956,92.229,210.566,92.354,211.237,92.354z
     M212.479,75.186l2.804,1.22l-2.74,2.569h-2.483L212.479,75.186z"/>
  <path fill="#5B5B5B" d="M222.112,80.152h3.04l7.022,9.227v-9.227h3.254v14.985h-2.805l-7.257-9.526v9.526h-3.254V80.152z"/>
</g>
<g>
  <path fill="#5B5B5B" d="M408.181,35.594h7.362c1.475,0,2.828,0.239,4.06,0.715c1.231,0.477,2.292,1.138,3.183,1.982
    c0.89,0.845,1.577,1.838,2.063,2.98c0.485,1.142,0.728,2.378,0.728,3.708v0.054c0,1.331-0.242,2.571-0.728,3.722
    c-0.486,1.151-1.174,2.149-2.063,2.994c-0.891,0.846-1.951,1.51-3.183,1.996c-1.231,0.485-2.585,0.728-4.06,0.728h-7.362V35.594z
     M415.543,50.724c0.846,0,1.619-0.135,2.32-0.404c0.701-0.27,1.299-0.656,1.793-1.16s0.881-1.097,1.16-1.78
    c0.278-0.683,0.418-1.447,0.418-2.292v-0.054c0-0.827-0.14-1.591-0.418-2.292c-0.279-0.701-0.666-1.304-1.16-1.807
    c-0.494-0.503-1.092-0.894-1.793-1.173c-0.701-0.278-1.475-0.418-2.32-0.418h-3.209v11.381H415.543z"/>
  <path fill="#5B5B5B" d="M429.46,35.594h4.153v18.879h-4.153V35.594z"/>
  <path fill="#5B5B5B" d="M445.075,54.743c-1.438,0-2.85-0.247-4.234-0.742c-1.385-0.494-2.643-1.254-3.775-2.279l2.454-2.94
    c0.863,0.702,1.748,1.259,2.656,1.672s1.901,0.62,2.98,0.62c0.863,0,1.533-0.157,2.01-0.472c0.476-0.314,0.714-0.75,0.714-1.308
    v-0.054c0-0.27-0.049-0.508-0.148-0.714s-0.288-0.4-0.568-0.58c-0.279-0.18-0.667-0.359-1.162-0.54
    c-0.496-0.179-1.141-0.368-1.934-0.566c-0.956-0.233-1.821-0.494-2.597-0.782s-1.433-0.643-1.974-1.065
    c-0.541-0.422-0.96-0.948-1.257-1.578c-0.298-0.629-0.446-1.412-0.446-2.347v-0.054c0-0.863,0.16-1.641,0.481-2.333
    c0.321-0.692,0.772-1.29,1.354-1.793c0.58-0.503,1.273-0.89,2.08-1.16c0.806-0.27,1.694-0.405,2.665-0.405
    c1.385,0,2.657,0.207,3.816,0.621c1.16,0.414,2.226,1.007,3.196,1.78l-2.158,3.128c-0.845-0.575-1.672-1.029-2.48-1.362
    c-0.81-0.333-1.619-0.499-2.428-0.499c-0.81,0-1.416,0.158-1.82,0.472s-0.607,0.706-0.607,1.173v0.054
    c0,0.306,0.059,0.571,0.176,0.795c0.117,0.225,0.329,0.427,0.636,0.607c0.307,0.18,0.726,0.351,1.258,0.513
    c0.531,0.162,1.203,0.351,2.015,0.566c0.955,0.252,1.807,0.535,2.556,0.849c0.748,0.315,1.379,0.692,1.893,1.133
    c0.514,0.441,0.901,0.958,1.163,1.551c0.261,0.593,0.392,1.304,0.392,2.131v0.054c0,0.935-0.17,1.767-0.509,2.495
    c-0.34,0.728-0.813,1.339-1.42,1.834s-1.333,0.872-2.175,1.132C447.034,54.613,446.101,54.743,445.075,54.743z"/>
</g>

<a href="http://dis.laplata.gov.ar" target="_blank">
<circle opacity="0.01" fill="#FFFFFF" cx="430.2" cy="60.03" r="53.167"/>
</a>
<a href="http://lab.laplata.gov.ar" target="_blank">
<circle opacity="0.01" fill="#FFFFFF" cx="306.867" cy="58.03" r="53.167"/>
</a>
</svg>-->













          </div>
        </div>
      </div>
    </div>
  </div>

  <a class="scrolltop" href="#"><span class="fa fa-angle-up"></span></a>


  <!-- Required JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/tether/js/tether.min.js"></script>
  <script src="lib/stellar/stellar.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/easing/easing.js"></script>
  <script src="lib/stickyjs/sticky.js"></script>
  <script src="lib/parallax/parallax.js"></script>
  <script src="lib/lockfixed/lockfixed.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
  <!-- Template Specisifc Custom Javascript File -->
  <script src="js/custom.js"></script>
  <script src="js/calendar.js"></script>
  <script src="js/index.js"></script>
  <script src="js/download.js"></script>
  <script src="https://unpkg.com/imask"></script>

  <script src="contactform/contactform.js"></script>



<script type="text/javascript">
    jQuery(document).ready(function() {
        App.init();
        App.initSliders();
        Index.initParallaxSlider();
    });
 $(window).load(function() {
                $("#chat-application-iframe").contents().find(".brand").hide();

    });




</script>
<script type="text/javascript">
        
        function talcosa(){
          (function($){
                //creamos la fecha actual
                var date = new Date();
                var yyyy = $("#ANIO").val();
                var mm = (date.getMonth()+1).toString().length == 1 ? "0"+(date.getMonth()+1).toString() : (date.getMonth()+1).toString();
                var dd  = (date.getDate()).toString().length == 1 ? "0"+(date.getDate()).toString() : (date.getDate()).toString();

                //establecemos los valores del calendario
                var options = {

                    // definimos que los eventos se mostraran en ventana modal
                        modal: '#events-modal', 

                        // dentro de un iframe
                        modal_type:'iframe',    

                        //obtenemos los eventos de la base de datos
                        events_source: 'calendarioRafam/process.php?RECURSO='+$("#RECURSO").val()+'&ANIO='+$("#ANIO").val()+'&DESCRIPCION='+$("#RECURSO option:selected").text(), 

                        // mostramos el calendario en el mes
                        view: 'year',             

                        // y dia actual
                        day: yyyy+"-"+mm+"-"+dd,   


                        // definimos el idioma por defecto
                        language: 'es-ES', 

                        //Template de nuestro calendario
                        tmpl_path: '../tmpls/', 
                        tmpl_cache: false,


                        // Hora de inicio
                        time_start: '08:00', 

                        // y Hora final de cada dia
                        time_end: '22:00',   

                        // intervalo de tiempo entre las hora, en este caso son 30 minutos
                        time_split: '30',    

                        // Definimos un ancho del 100% a nuestro calendario
                        width: '100%', 

                        onAfterEventsLoad: function(events)
                        {
                                if(!events)
                                {
                                        return;
                                }
                                var list = $('#eventlist');
                                list.html('');

                                $.each(events, function(key, val)
                                {
                                        $(document.createElement('li'))
                                                .html(val.title)
                                                .appendTo(list);
                                });
                        },
                        onAfterViewLoad: function(view)
                        {
                                $('#valores').text(this.getTitle());
                                $('.btn-group button').removeClass('active');
                                $('button[data-calendar-view="' + view + '"]').addClass('active');
                        },
                        classes: {
                                months: {
                                        general: 'label'
                                }
                        }
                };


                // id del div donde se mostrara el calendario
                var calendar = $('#calendar').calendar(options); 

                $('.btn-group button[data-calendar-nav]').each(function()
                {
                        var $this = $(this);
                        $this.click(function()
                        {
                                calendar.navigate($this.data('calendar-nav'));
                        });
                });

                $('.btn-group button[data-calendar-view]').each(function()
                {
                        var $this = $(this);
                        $this.click(function()
                        {
                          calendar.view($this.data('calendar-view'));
                        });
                });

                $('#first_day').change(function()
                {
                        var value = $(this).val();
                        value = value.length ? parseInt(value) : null;
                        calendar.setOptions({first_day: value});
                        calendar.view();
                });
        }(jQuery));
        }


$('#RECURSO').change(function(){
$('#DESCRIPCION').val()= $(this).val();
});



    </script>

    
<script>    
function chatear()
{
  smartsupp('chat:open');
}
function RG()
{
  $("#collapseOne").collapse('hide');
  $("#collapse3").collapse('hide');
  $("#collapseTwo").collapse('show');
  $('#2016').collapse('show');
}
function IT()
{
  $("#collapseOne").collapse('hide');
  $("#collapseTwo").collapse('hide');
  $("#collapse3").collapse('show');
}
function MM()
{
  $("#collapseTwo").collapse('hide');
  $("#collapse3").collapse('hide');
  $("#collapseOne").collapse('show');
}
</script>



<script>

    $(document).ready(function(){



    $('#rodado').hide();
$('#comercio').hide();
$('#contribuyente').hide();



$('#imponible').change(function()
                {
                        var value = $(this).val();

                        if (  value == 'I') {
                            $('#inmueble').show();
                           $('#rodado').hide();
                           $('#comercio').hide();
                           $('#contribuyente').hide();
                        }
                        if (  value == 'R') {
                            $('#inmueble').hide();
                           $('#rodado').show();
                           $('#comercio').hide();
                           $('#contribuyente').hide();
                        }
                        if (  value == 'C') {
                            $('#inmueble').hide();
                           $('#rodado').hide();
                           $('#comercio').show();
                           $('#contribuyente').hide();
                        }
                        if (  value == 'N') {
                            $('#inmueble').hide();
                           $('#rodado').hide();
                           $('#comercio').hide();
                           $('#contribuyente').show();
                        }

                      });


$( "#imprimir" ).click(function( event ) {
  if ($( "#imponible" ).val() == 'I' ) {


    window.open("http://pdf.apronline.gov.ar/ultimaboleta_M/I/"+$('#partida').val()+"-"+$('#prepartida').val(), '_blank');


}

  if ($( "#imponible" ).val() == 'R' ) {

        window.open("http://pdf.apronline.gov.ar/ultimaboleta_M/R/"+$('#rodadotxt').val(), '_blank');


  }

  if ($( "#imponible" ).val() == 'C' ) {
        window.open("http://pdf.apronline.gov.ar/ultimaboleta_M/R/"+$('#cuit2').val(), '_blank');

  }

  if ($( "#imponible" ).val() == 'N' ) {
        window.open("http://pdf.apronline.gov.ar/ultimaboleta_M/R/"+$('#cuimtxt').val(), '_blank');

  }

});



});

</script>















    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<script type="text/javascript">
  
  talcosa();



</script>

<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = 'f8006331fbe354894a8473786899429f222dd8f3';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);

setTimeout(function(){$("#chat-application-iframe").contents().find(".brand").hide();}, 3000);

</script>


</body>
</html>
